export class TemporadasService {
    
      registros=['2017/18','2016/17','2015/16','2014/15','2013/14','2012/13','2011/12','2010/11','2009/10']
      getRegistros(){
        return this.registros;
      }
    }
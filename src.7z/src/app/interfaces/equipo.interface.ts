export interface Equipo{
  Nombre:string;
  Escudo: string;
  Password:string;
  $key?:string;
}
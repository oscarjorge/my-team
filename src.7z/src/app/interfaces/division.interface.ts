export interface Division{
    Nombre:string;
    $key?:string;
  }
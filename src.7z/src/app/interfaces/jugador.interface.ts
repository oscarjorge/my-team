
export interface Jugador{
  Nombre:string;
  Equipos: any[];
  Imagen:string;
  Caracteristicas:string;
  Apodo:string;
  key$?:string;
}

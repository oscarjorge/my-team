export interface Grupo{
    Nombre:string;
    $key?:string;
  }
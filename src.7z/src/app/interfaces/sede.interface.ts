export interface Sede{
    Nombre:string;
    $key?:string;
  }
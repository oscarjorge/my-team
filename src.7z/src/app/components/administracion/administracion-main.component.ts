import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'admin-main',
    templateUrl: 'administracion-main.component.html',
    styleUrls: ['administracion-main.component.css']
})

export class AdministracionMainComponent implements OnInit {
    constructor() { }

    ngOnInit() { 
        
    }
    
}

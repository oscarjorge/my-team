import { Component, OnInit, Input } from '@angular/core';
import { PartidosService } from '../../services/partidos.service';
import { JugadoresService } from '../../services/jugadores.service';
import { EquiposService } from '../../services/equipos.service';
import { TorneosService } from '../../services/torneos.service';
import { UsuariosService } from '../../services/usuarios.service';
import { Clasificacion } from '../../interfaces/clasificacion.interface';
import { EquipoClasificacion } from '../../interfaces/clasificacion.interface';


@Component({
  selector: 'graficoGolesJugadores',
  templateUrl: './golesJugadores.component.html',
  styles: []
})
export class GolesJugadoresComponent implements OnInit {

  public lineChartData: Array<any>;
  public lineChartLabels: Array<any>;
  public cargargrafico: boolean = false;
  public estadistica: string = "GolesMarcados";
  public jugadorGrafico: string[] = ["1", "0"];
  private ultimoFiltro: any;
  constructor(
    private _partidosService: PartidosService,
    private _usuariosService: UsuariosService,
    private _jugadoresService: JugadoresService,
    private _equiposService: EquiposService,
    private _torneosService: TorneosService
  ) { }
  @Input() jugadorKey: string;

  torneos:any[];
  torneosAll:any[];
  equiposJugador: any[];
  jugadoresDelEquipo: any[];
  equiposJugadores: any[];
  ngOnInit() {
    if(this.jugadorKey!=null){
      this._torneosService.getRegistros().subscribe(torneosData=>{
        this.torneosAll=torneosData;
        this.torneos=torneosData;
        this._equiposService.getEquipos().subscribe(equipos=>{
          this._jugadoresService.getJugador(this.jugadorKey).then(jugador => {
             (<any[]>jugador["Equipos"]).forEach(e=>{
              this.equiposJugador.push(equipos.find(eq=>eq.$key==e.Key));
             });
            
          });
        })
      })
      // this._jugadoresService.getJugador(this.jugadorKey).then(jugador => {
      //   this.equiposJugador=jugador["Equipos"];
      //   // (<any[]>jugador["Equipos"]).forEach(equipo=>{
      //   //   this._jugadoresService.getJugadoresPorEquipo(equipo["Key"]).then(jugadores => {
      //   //     this.jugadoresDelEquipo = <any[]>jugadores;
            
      //   //   });
      //   // })
        
      // });
    }
  }
  onEquipoChange(key){

  }
  onCheckEstadistica(e) {
    this.estadistica = e.target.value;
    this.dibujarGrafico()
  }
  filtroChanged(filtro) {
    this.ultimoFiltro = filtro;
    this.dibujarGrafico()
  }
  dibujarGrafico() {
    this.cargargrafico = false;
    let arrJugadoresEstadisticas: any[] = [];
    this.jugadorGrafico.forEach(jug => {
      this._jugadoresService.getJugador(jug).then(jugador => {
        this._partidosService.getGolesJugadores(this.ultimoFiltro.Torneo, jugador["$key"], this.estadistica).then(data => {
          arrJugadoresEstadisticas.push({ data: data["goles"], label: jugador["Nombre"] });
          if (arrJugadoresEstadisticas.length == this.jugadorGrafico.length) {
            this.lineChartLabels = data["jornadas"];
            this.lineChartData = arrJugadoresEstadisticas;
          }
        })
      })
    })

  }
  public lineChartOptions: any = {
    responsive: true
  };
  public lineChartColors: Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    },
    { // dark grey
      backgroundColor: 'rgba(77,83,96,0.2)',
      borderColor: 'rgba(77,83,96,1)',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    },
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend: boolean = true;
  public lineChartType: string = 'line';

  public chartClicked(e: any): void {
    console.log(e);
  }

  public chartHovered(e: any): void {
    console.log(e);
  }





}










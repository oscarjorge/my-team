/* SystemJS module definition */
declare var $: any;
declare var moment: any;
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
